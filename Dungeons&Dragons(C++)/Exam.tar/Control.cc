#include <iostream>
using namespace std;

#include <string>
#include "Control.h"


Control::Control()
{
}

Control::~Control()
{
}

void Control::launch()
{
 game.start();
}







