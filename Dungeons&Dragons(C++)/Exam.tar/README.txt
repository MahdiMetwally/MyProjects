program and revision authors: Mahdi Metwally.

purpose:
-The purpose of this program is to manage a group of students by implementing
class templates, overloading operators, and exception handling to handle errors.

source/header/data files:

Header Files:
-Control.h
-Dragon.h
-Fighter.h
-Game.h
-Hero.h
-List.h
-Player.h
-Potion.h
-Setting.h
-Wizard.h


Source Files
-Control.cc
-Dragon.cc
-Fighter.cc
-Game.cc
-Hero.cc
-List.cc
-main.cc
-Player.cc
-Potion.cc
-random.cc
-Wizard.cc
-random.cc

Data Files:
-Makefile

compilation and launching instructions:
-untar the Exam.tar file by entering "tar -xvf Exam.tar" into the command 
prompt where the Exam.tar file is available in the current directory.

-once the Exam.tar file is untar'd enter "make" into the command prompt given all the provided Exam files are in the current directory.

-enter "./E1" into the command prompt to execute the program.

-follow on-screen intructions to properly use the program.

-to test for memory leaks enter "valgrind --leak-check=yes ./E1".


Innovative Features:

-Fire Breath:
 In the game, the dragon located at the cave is capable of breathing fire that reaches
 the entire width of the game map. the only players that this can kill includes the heroes,
 Timmy and Harold. The heroes can block one another and sacrifice themselves to the fire, sparing
 the hero that is standing directly behind the unfortunate hero. If the heroes are standing at the exact
 same position, then the fire will instantly  kill both heroes and the game will end. Note: there is a
 30 percent chance of the dragon breathing fire at each iteration.
 
-Wizards with potions:
 Wizards can be found in the death Hollow and have a 20 percent chance of spawning. If a hero 
 encounters a wizard, the wizard will provide the hero with a potion that has random health, strength, 
 and armour enhancements. The wizard will only provide the heroes with potions and is immune to 
 fire breath due to his fire-resistant cloak and invisible to wandering enemies because of his
 disguise spell. The wizards store Potion objects in a linked list.





