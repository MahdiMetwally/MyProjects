#include <iostream>
using namespace std;
#include <string>
#include <cstdlib>
#include <time.h>
#include "Control.h"


int main()
{
  Control control;
  control.launch();

  return 0;
}

