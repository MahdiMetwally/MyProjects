#ifndef CONTROL_H
#define CONTROL_H

#include "Game.h"

class Control
{
  public:
  Control();
  ~Control();
  void launch();

  private:
  Game game;

};

#endif
